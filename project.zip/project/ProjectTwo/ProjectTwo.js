var num1, num2, operation;  // Declared variables 
num1 = 5;                   // Example of variables
num2 = 2;                     
function addition(num1, num2){  // Addition function
    return num1 + num2          // Returns addition of variables 
}                               

function subtraction(num1, num2){ // subtract function
    return num1 - num2            // Returns subtraction of variables
}

function multiplication(num1, num2){ // Multiplication function
    return num1 * num2               // Returns multiplication of variables
}

function division(num1, num2){  // Division function
    return num1 / num2          // Returns devision of method
}

switch (operation) {   // Which operation user wants to perform.
    case 0: 
     console.log(addition(num1, num2)) // Calls the functions and prints the results 
     break;
    case 1:
     console.log(subtraction(num1, num2))  
     break;
    case 2:
     console.log(multiplication(num1, num2))
     break;
    case 3:
     console.log(division(num1, num2))
     break;
    default:
      text = "Please choose operator";  // In case if user write anything else. 
    }