const fruits = ["Apple", "Orange", "Banana", "Pear",
 "Peach", "Strawberry","Cherry","Acai"];    // Storing strings
fruits.toLowerCase(); // Cover to lower Case all strings

let text;
for (let i = 0; i < fruits.length; i++) { // Using loop to count number of strings
  
    var consonants = 0;  // Declaring consonants and vowels.
    var vowels = 0;

    for (let i = 0; i < fruits.char; i++) { // Searching through each character

       if (fruits == "a" || fruits == "e" || fruits == "i"  || fruits == "o" || fruits == "u"){
            vowels = vowels + 1; // If Vowel is detected add one
        } else {
            consonants = consonants + 1; // If consonants is dectected add one
        }
}
  console.log("Number of fruits: " + fruits.length);  // Presenting number of fruits 
  console.log("Number of vowels: " + vowels);         // Presenting number of vowels
  console.log("Number of Consonants: " + consonants); // Presenting number of consonants
}

